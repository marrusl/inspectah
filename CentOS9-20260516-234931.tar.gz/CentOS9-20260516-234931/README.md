# inspectah output

> **WARNING: Incomplete inspection**
>
> The following inspector sections may be missing or degraded: config
> Reason: one or more inspectors returned degraded results
>
> Review the audit report for details before building.

Generated from **CentOS Stream 9**.

## Findings summary

| Category | Count |
|---|---|
| Packages added (beyond base image) | 477 |
| Services (21 enabled, 23 disabled) | 44 |
| Non-RPM software items | 1 |
| Secrets redacted | 23 |
| Warnings | 1 |

## Build and deploy

```bash
podman build -t my-bootc-image -f Containerfile .
```

```bash
# Custom kernel args detected -- verify they are baked into the image
# or pass them via the bootloader configuration at deploy time.
# Switch an existing system to the new image:
bootc switch my-bootc-image:latest

# Or install to a new disk:
bootc install to-disk --target-no-signature-verification /dev/sdX
```

Review `kickstart-suggestion.ks` for deployment-time settings (hostname, DHCP, DNS).

## Artifacts

| File | Description |
|---|---|
| `Containerfile` | Image definition |
| `config/` | Files to COPY into the image |
| `audit-report.md` | Full findings (markdown) |
| `report.html` | Interactive report (open in browser) |
| `secrets-review.md` | Redacted items requiring manual handling |
| `kickstart-suggestion.ks` | Suggested deploy-time settings |
| `inspection-snapshot.json` | Raw data for re-rendering (`--from-snapshot`) |

## Warnings

- **Config:** degraded: config inspector degraded: file too large (541716 bytes): /etc/ssh/moduli; file too large (676522 bytes): /etc/ssl/certs/ca-bundle.trust.crt; file too large (692252 bytes): /etc/services

See [`audit-report.md`](audit-report.md) or [`report.html`](report.html) for full details.
