#version=RHEL9

# Kickstart suggestion -- review and adapt for your environment
# These settings belong at deploy time, not baked into the image.

# --- DHCP connections ---
network --bootproto=dhcp --device=enp0s5 --activate

# --- Static route files detected ---
# These files were present on the source host. Review each and translate
# to NM connection properties (+ipv4.routes) or kickstart route directives.
# FIXME: review etc/iproute2/README and add equivalent route to NM connection or kickstart

# --- Examples ---
# network --bootproto=dhcp --device=eth0
# network --hostname=myhost.example.com
# network --bootproto=static --ip=192.168.1.10 --netmask=255.255.255.0 --gateway=192.168.1.1
