# Audit Report

## Incomplete Sections

### Degraded (partial data collected)

- `config`

**Reason:** one or more inspectors returned degraded results

Artifacts generated from this snapshot may be missing data from these sections.

**Source system:** CentOS Stream 9

## Packages

### Added Packages (477)

| Name | Version | Release | Arch | Repo |
|------|---------|---------|------|------|
| tzdata | 2025c | 1.el9 | noarch | anaconda |
| libreport-filesystem | 2.15.2 | 6.el9 | noarch | anaconda |
| dnf-data | 4.14.0 | 33.el9 | noarch | anaconda |
| gawk-all-langpacks | 5.1.0 | 6.el9 | aarch64 | AppStream |
| python3-setuptools-wheel | 53.0.0 | 15.el9 | noarch | anaconda |
| publicsuffix-list-dafsa | 20210518 | 3.el9 | noarch | anaconda |
| pcre2-syntax | 10.40 | 6.el9 | noarch | anaconda |
| ncurses-base | 6.2 | 12.20210508.el9 | noarch | anaconda |
| linux-firmware-whence | 20260130 | 160.el9 | noarch | anaconda |
| linux-firmware | 20260130 | 160.el9 | noarch | anaconda |
| libssh-config | 0.10.4 | 17.el9 | noarch | anaconda |
| kbd-misc | 2.4.0 | 11.el9 | noarch | anaconda |
| kbd-legacy | 2.4.0 | 11.el9 | noarch | anaconda |
| hwdata | 0.348 | 9.22.el9 | noarch | anaconda |
| fonts-filesystem | 2.0.5 | 7.el9.1 | noarch | anaconda |
| dejavu-sans-fonts | 2.37 | 18.el9 | noarch | anaconda |
| langpacks-core-font-en | 3.0 | 16.el9 | noarch | AppStream |
| firewalld-filesystem | 1.3.4 | 18.el9 | noarch | anaconda |
| coreutils-common | 8.32 | 40.el9 | aarch64 | anaconda |
| centos-gpg-keys | 9.0 | 35.el9 | noarch | anaconda |
| centos-stream-repos | 9.0 | 35.el9 | noarch | anaconda |
| centos-stream-release | 9.0 | 35.el9 | noarch | anaconda |
| setup | 2.13.7 | 10.el9 | noarch | anaconda |
| filesystem | 3.16 | 5.el9 | aarch64 | anaconda |
| efi-filesystem | 6 | 4.el9 | noarch | anaconda |
| basesystem | 11 | 13.el9 | noarch | anaconda |
| ncurses-libs | 6.2 | 12.20210508.el9 | aarch64 | anaconda |
| bash | 5.1.8 | 9.el9 | aarch64 | anaconda |
| libgcc | 11.5.0 | 14.el9 | aarch64 | anaconda |
| glibc-gconv-extra | 2.34 | 256.el9 | aarch64 | anaconda |
| glibc-langpack-en | 2.34 | 256.el9 | aarch64 | anaconda |
| glibc-common | 2.34 | 256.el9 | aarch64 | anaconda |
| glibc | 2.34 | 256.el9 | aarch64 | anaconda |
| zlib | 1.2.11 | 41.el9 | aarch64 | anaconda |
| xz-libs | 5.2.5 | 8.el9 | aarch64 | anaconda |
| libzstd | 1.5.5 | 1.el9 | aarch64 | anaconda |
| popt | 1.18 | 8.el9 | aarch64 | anaconda |
| libcap | 2.48 | 10.el9 | aarch64 | anaconda |
| libuuid | 2.37.4 | 25.el9 | aarch64 | anaconda |
| bzip2-libs | 1.0.8 | 11.el9 | aarch64 | anaconda |
| sqlite-libs | 3.34.1 | 9.el9 | aarch64 | anaconda |
| libstdc++ | 11.5.0 | 14.el9 | aarch64 | anaconda |
| libxcrypt | 4.4.18 | 3.el9 | aarch64 | anaconda |
| libcom_err | 1.46.5 | 8.el9 | aarch64 | anaconda |
| libmnl | 1.0.4 | 16.el9 | aarch64 | anaconda |
| crypto-policies | 20251126 | 1.gite9c4db2.el9 | noarch | anaconda |
| elfutils-libelf | 0.194 | 1.el9 | aarch64 | anaconda |
| libxml2 | 2.9.13 | 14.el9 | aarch64 | anaconda |
| readline | 8.1 | 4.el9 | aarch64 | anaconda |
| nspr | 4.36.0 | 4.el9 | aarch64 | AppStream |
| nss-util | 3.112.0 | 4.el9 | aarch64 | AppStream |
| alternatives | 1.24 | 2.el9 | aarch64 | anaconda |
| keyutils-libs | 1.6.3 | 1.el9 | aarch64 | anaconda |
| libcap-ng | 0.8.2 | 7.el9 | aarch64 | anaconda |
| audit-libs | 3.1.5 | 8.el9 | aarch64 | anaconda |
| libffi | 3.4.2 | 8.el9 | aarch64 | anaconda |
| libgpg-error | 1.42 | 5.el9 | aarch64 | anaconda |
| libunistring | 0.9.10 | 15.el9 | aarch64 | anaconda |
| lua-libs | 5.4.4 | 4.el9 | aarch64 | anaconda |
| expat | 2.5.0 | 6.el9 | aarch64 | anaconda |
| gmp | 6.2.0 | 13.el9 | aarch64 | anaconda |
| json-c | 0.14 | 11.el9 | aarch64 | anaconda |
| libtalloc | 2.4.3 | 1.el9 | aarch64 | anaconda |
| pcre2 | 10.40 | 6.el9 | aarch64 | anaconda |
| libidn2 | 2.3.0 | 7.el9 | aarch64 | anaconda |
| libattr | 2.5.1 | 3.el9 | aarch64 | anaconda |
| libacl | 2.3.1 | 4.el9 | aarch64 | anaconda |
| libedit | 3.1 | 39.20210216cvs.el9 | aarch64 | anaconda |
| libsepol | 3.6 | 3.el9 | aarch64 | anaconda |
| libselinux | 3.6 | 3.el9 | aarch64 | anaconda |
| sed | 4.8 | 9.el9 | aarch64 | anaconda |
| findutils | 4.8.0 | 7.el9 | aarch64 | anaconda |
| libsmartcols | 2.37.4 | 25.el9 | aarch64 | anaconda |
| lz4-libs | 1.9.3 | 5.el9 | aarch64 | anaconda |
| libsemanage | 3.6 | 5.el9 | aarch64 | anaconda |
| shadow-utils | 4.9 | 16.el9 | aarch64 | anaconda |
| libtevent | 0.17.1 | 1.el9 | aarch64 | anaconda |
| libgcrypt | 1.10.0 | 11.el9 | aarch64 | anaconda |
| file-libs | 5.39 | 16.el9 | aarch64 | anaconda |
| gdbm-libs | 1.23 | 1.el9 | aarch64 | anaconda |
| jansson | 2.14 | 1.el9 | aarch64 | anaconda |
| libnl3 | 3.11.0 | 1.el9 | aarch64 | anaconda |
| libtasn1 | 4.16.0 | 9.el9 | aarch64 | anaconda |
| p11-kit | 0.26.2 | 1.el9 | aarch64 | anaconda |
| p11-kit-trust | 0.26.2 | 1.el9 | aarch64 | anaconda |
| libtdb | 1.4.14 | 1.el9 | aarch64 | anaconda |
| mpfr | 4.1.0 | 10.el9 | aarch64 | anaconda |
| libassuan | 2.5.5 | 3.el9 | aarch64 | anaconda |
| libbpf | 1.5.0 | 3.el9 | aarch64 | anaconda |
| libnftnl | 1.2.6 | 4.el9 | aarch64 | anaconda |
| gdisk | 1.0.7 | 5.el9 | aarch64 | AppStream |
| efivar-libs | 38 | 3.el9 | aarch64 | anaconda |
| fuse-libs | 2.9.9 | 17.el9 | aarch64 | anaconda |
| libaio | 0.3.111 | 13.el9 | aarch64 | anaconda |
| libatomic | 11.5.0 | 14.el9 | aarch64 | anaconda |
| libbasicobjects | 0.1.1 | 53.el9 | aarch64 | anaconda |
| libcollection | 0.7.0 | 53.el9 | aarch64 | anaconda |
| libdhash | 0.5.0 | 53.el9 | aarch64 | anaconda |
| libgomp | 11.5.0 | 14.el9 | aarch64 | anaconda |
| libref_array | 0.1.5 | 53.el9 | aarch64 | anaconda |
| libseccomp | 2.5.2 | 2.el9 | aarch64 | anaconda |
| libsigsegv | 2.13 | 4.el9 | aarch64 | anaconda |
| gawk | 5.1.0 | 6.el9 | aarch64 | anaconda |
| libsss_idmap | 2.9.8 | 1.el9 | aarch64 | anaconda |
| lzo | 2.10 | 7.el9 | aarch64 | anaconda |
| pcre | 8.44 | 4.el9 | aarch64 | anaconda |
| grep | 3.6 | 5.el9 | aarch64 | anaconda |
| openssl-fips-provider | 3.5.5 | 1.el9 | aarch64 | anaconda |
| openssl-libs | 3.5.5 | 1.el9 | aarch64 | anaconda |
| coreutils | 8.32 | 40.el9 | aarch64 | anaconda |
| ca-certificates | 2025.2.80_v9.0.305 | 91.el9 | noarch | anaconda |
| systemd-libs | 252 | 64.el9 | aarch64 | anaconda |
| libblkid | 2.37.4 | 25.el9 | aarch64 | anaconda |
| kmod-libs | 28 | 11.el9 | aarch64 | anaconda |
| libmount | 2.37.4 | 25.el9 | aarch64 | anaconda |
| dbus-libs | 1.12.20 | 8.el9 | aarch64 | anaconda |
| kmod | 28 | 11.el9 | aarch64 | anaconda |
| util-linux-core | 2.37.4 | 25.el9 | aarch64 | anaconda |
| libfdisk | 2.37.4 | 25.el9 | aarch64 | anaconda |
| gzip | 1.12 | 1.el9 | aarch64 | anaconda |
| cracklib | 2.9.6 | 28.el9 | aarch64 | anaconda |
| libusbx | 1.0.26 | 1.el9 | aarch64 | anaconda |
| libarchive | 3.5.3 | 6.el9 | aarch64 | anaconda |
| libnvme | 1.16.1 | 2.el9 | aarch64 | anaconda |
| cracklib-dicts | 2.9.6 | 28.el9 | aarch64 | anaconda |
| device-mapper-persistent-data | 1.1.0 | 1.el9 | aarch64 | anaconda |
| procps-ng | 3.3.17 | 14.el9 | aarch64 | anaconda |
| libatasmart | 0.19 | 22.el9 | aarch64 | AppStream |
| python3-pip-wheel | 21.3.1 | 1.el9 | noarch | anaconda |
| python-unversioned-command | 3.9.25 | 3.el9 | noarch | AppStream |
| python3 | 3.9.25 | 3.el9 | aarch64 | anaconda |
| python3-libs | 3.9.25 | 3.el9 | aarch64 | anaconda |
| python3-six | 1.15.0 | 9.el9 | noarch | anaconda |
| python3-dateutil | 2.9.0.post0 | 1.el9 | noarch | anaconda |
| python3-systemd | 234 | 19.el9 | aarch64 | anaconda |
| libcap-ng-python3 | 0.8.2 | 7.el9 | aarch64 | AppStream |
| openssl | 3.5.5 | 1.el9 | aarch64 | anaconda |
| libevent | 2.1.12 | 8.el9 | aarch64 | anaconda |
| libsss_certmap | 2.9.8 | 1.el9 | aarch64 | anaconda |
| mokutil | 0.7.2 | 4.el9 | aarch64 | anaconda |
| xz | 5.2.5 | 8.el9 | aarch64 | anaconda |
| squashfs-tools | 4.4 | 10.git1.el9 | aarch64 | anaconda |
| numactl-libs | 2.0.19 | 3.el9 | aarch64 | anaconda |
| libbytesize | 2.5 | 3.el9 | aarch64 | AppStream |
| libnl3-cli | 3.11.0 | 1.el9 | aarch64 | anaconda |
| libteam | 1.31 | 16.el9 | aarch64 | anaconda |
| file | 5.39 | 16.el9 | aarch64 | anaconda |
| libutempter | 1.2.1 | 6.el9 | aarch64 | anaconda |
| libselinux-utils | 3.6 | 3.el9 | aarch64 | anaconda |
| acl | 2.3.1 | 4.el9 | aarch64 | anaconda |
| gettext-libs | 0.21 | 8.el9 | aarch64 | anaconda |
| gettext | 0.21 | 8.el9 | aarch64 | anaconda |
| attr | 2.5.1 | 3.el9 | aarch64 | anaconda |
| libpsl | 0.21.1 | 5.el9 | aarch64 | anaconda |
| libcomps | 0.1.18 | 1.el9 | aarch64 | anaconda |
| python3-libcomps | 0.1.18 | 1.el9 | aarch64 | anaconda |
| libksba | 1.5.1 | 7.el9 | aarch64 | anaconda |
| keyutils | 1.6.3 | 1.el9 | aarch64 | anaconda |
| nss-softokn-freebl | 3.112.0 | 4.el9 | aarch64 | AppStream |
| nss-softokn | 3.112.0 | 4.el9 | aarch64 | AppStream |
| ethtool | 6.15 | 2.el9 | aarch64 | anaconda |
| ipset-libs | 7.11 | 11.el9 | aarch64 | anaconda |
| ipset | 7.11 | 11.el9 | aarch64 | anaconda |
| e2fsprogs-libs | 1.46.5 | 8.el9 | aarch64 | anaconda |
| libss | 1.46.5 | 8.el9 | aarch64 | anaconda |
| e2fsprogs | 1.46.5 | 8.el9 | aarch64 | anaconda |
| groff-base | 1.22.4 | 10.el9 | aarch64 | anaconda |
| snappy | 1.1.8 | 8.el9 | aarch64 | anaconda |
| pigz | 2.5 | 4.el9 | aarch64 | anaconda |
| c-ares | 1.19.1 | 2.el9 | aarch64 | anaconda |
| cpio | 2.13 | 16.el9 | aarch64 | anaconda |
| diffutils | 3.7 | 12.el9 | aarch64 | anaconda |
| dmidecode | 3.6 | 2.el9 | aarch64 | anaconda |
| dosfstools | 4.2 | 3.el9 | aarch64 | anaconda |
| hostname | 3.23 | 6.el9 | aarch64 | anaconda |
| inih | 49 | 6.el9 | aarch64 | anaconda |
| kernel-tools-libs | 5.14.0 | 686.el9 | aarch64 | anaconda |
| less | 590 | 6.el9 | aarch64 | anaconda |
| libbrotli | 1.0.9 | 9.el9 | aarch64 | anaconda |
| libcbor | 0.7.0 | 5.el9 | aarch64 | anaconda |
| libdaemon | 0.14 | 23.el9 | aarch64 | anaconda |
| teamd | 1.31 | 16.el9 | aarch64 | anaconda |
| libdb | 5.3.28 | 57.el9 | aarch64 | anaconda |
| libeconf | 0.4.1 | 5.el9 | aarch64 | anaconda |
| libpwquality | 1.4.4 | 8.el9 | aarch64 | anaconda |
| pam | 1.5.1 | 28.el9 | aarch64 | anaconda |
| util-linux | 2.37.4 | 25.el9 | aarch64 | anaconda |
| grub2-common | 2.06 | 124.el9 | noarch | anaconda |
| openssh | 9.9p1 | 3.el9 | aarch64 | anaconda |
| kbd | 2.4.0 | 11.el9 | aarch64 | anaconda |
| libndp | 1.9 | 1.el9 | aarch64 | anaconda |
| libnfnetlink | 1.0.1 | 23.el9 | aarch64 | anaconda |
| libnetfilter_conntrack | 1.0.9 | 1.el9 | aarch64 | anaconda |
| iptables-libs | 1.8.10 | 11.el9 | aarch64 | anaconda |
| iptables-nft | 1.8.10 | 11.el9 | aarch64 | anaconda |
| nftables | 1.0.9 | 6.el9 | aarch64 | anaconda |
| python3-nftables | 1.0.9 | 6.el9 | aarch64 | anaconda |
| libnghttp2 | 1.43.0 | 6.el9 | aarch64 | anaconda |
| libpath_utils | 0.2.1 | 53.el9 | aarch64 | anaconda |
| libini_config | 1.3.1 | 53.el9 | aarch64 | anaconda |
| libpipeline | 1.5.3 | 4.el9 | aarch64 | anaconda |
| libsss_nss_idmap | 2.9.8 | 1.el9 | aarch64 | anaconda |
| libsss_sudo | 2.9.8 | 1.el9 | aarch64 | anaconda |
| libtool-ltdl | 2.4.6 | 46.el9 | aarch64 | anaconda |
| libverto | 0.3.2 | 3.el9 | aarch64 | anaconda |
| krb5-libs | 1.21.1 | 8.el9 | aarch64 | anaconda |
| cyrus-sasl-lib | 2.1.27 | 21.el9 | aarch64 | anaconda |
| openldap | 2.6.8 | 4.el9 | aarch64 | anaconda |
| libssh | 0.10.4 | 17.el9 | aarch64 | anaconda |
| libcurl | 7.76.1 | 40.el9 | aarch64 | anaconda |
| tpm2-tss | 3.2.3 | 1.el9 | aarch64 | anaconda |
| ima-evm-utils | 1.6.2 | 2.el9 | aarch64 | anaconda |
| curl | 7.76.1 | 40.el9 | aarch64 | anaconda |
| rpm | 4.16.1.3 | 40.el9 | aarch64 | anaconda |
| rpm-libs | 4.16.1.3 | 40.el9 | aarch64 | anaconda |
| libsolv | 0.7.24 | 4.el9 | aarch64 | anaconda |
| policycoreutils | 3.6 | 5.el9 | aarch64 | anaconda |
| selinux-policy | 38.1.73 | 1.el9 | noarch | anaconda |
| selinux-policy-targeted | 38.1.73 | 1.el9 | noarch | anaconda |
| rpm-plugin-systemd-inhibit | 4.16.1.3 | 40.el9 | aarch64 | AppStream |
| sssd-client | 2.9.8 | 1.el9 | aarch64 | anaconda |
| libyaml | 0.2.5 | 7.el9 | aarch64 | anaconda |
| lmdb-libs | 0.9.29 | 3.el9 | aarch64 | anaconda |
| libldb | 4.23.5 | 5.el9 | aarch64 | anaconda |
| nettle | 3.10.1 | 1.el9 | aarch64 | anaconda |
| gnutls | 3.8.10 | 3.el9 | aarch64 | anaconda |
| glib2 | 2.68.4 | 19.el9 | aarch64 | anaconda |
| polkit-libs | 0.117 | 14.el9 | aarch64 | anaconda |
| python3-dbus | 1.2.18 | 2.el9 | aarch64 | anaconda |
| NetworkManager-libnm | 1.54.3 | 2.el9 | aarch64 | anaconda |
| json-glib | 1.6.6 | 1.el9 | aarch64 | anaconda |
| libgudev | 237 | 1.el9 | aarch64 | anaconda |
| libmodulemd | 2.13.0 | 2.el9 | aarch64 | anaconda |
| shared-mime-info | 2.1 | 5.el9 | aarch64 | anaconda |
| libxmlb | 0.3.24 | 1.el9 | aarch64 | anaconda |
| gobject-introspection | 1.68.0 | 11.el9 | aarch64 | anaconda |
| python3-gobject-base-noarch | 3.40.1 | 6.el9 | noarch | anaconda |
| python3-gobject-base | 3.40.1 | 6.el9 | aarch64 | anaconda |
| python3-firewall | 1.3.4 | 18.el9 | noarch | anaconda |
| libgusb | 0.3.8 | 2.el9 | aarch64 | anaconda |
| libuser | 0.63 | 17.el9 | aarch64 | anaconda |
| libudisks2 | 2.9.4 | 12.el9 | aarch64 | AppStream |
| npth | 1.6 | 8.el9 | aarch64 | anaconda |
| gnupg2 | 2.3.3 | 5.el9 | aarch64 | anaconda |
| gpgme | 1.15.1 | 6.el9 | aarch64 | anaconda |
| libjcat | 0.1.6 | 3.el9 | aarch64 | anaconda |
| librepo | 1.19.0 | 1.el9 | aarch64 | anaconda |
| libdnf | 0.69.0 | 18.el9 | aarch64 | anaconda |
| python3-libdnf | 0.69.0 | 18.el9 | aarch64 | anaconda |
| python3-hawkey | 0.69.0 | 18.el9 | aarch64 | anaconda |
| python3-gpg | 1.15.1 | 6.el9 | aarch64 | anaconda |
| rpm-sign-libs | 4.16.1.3 | 40.el9 | aarch64 | anaconda |
| oniguruma | 6.9.6 | 1.el9.6 | aarch64 | anaconda |
| jq | 1.6 | 19.el9 | aarch64 | anaconda |
| pciutils-libs | 3.7.0 | 7.el9 | aarch64 | anaconda |
| psmisc | 23.4 | 3.el9 | aarch64 | anaconda |
| iproute | 6.17.0 | 2.el9 | aarch64 | anaconda |
| sg3_utils-libs | 1.47 | 10.el9 | aarch64 | anaconda |
| slang | 2.3.2 | 11.el9 | aarch64 | anaconda |
| newt | 0.52.21 | 11.el9 | aarch64 | anaconda |
| userspace-rcu | 0.12.1 | 6.el9 | aarch64 | anaconda |
| which | 2.21 | 30.el9 | aarch64 | anaconda |
| libestr | 0.1.11 | 4.el9 | aarch64 | AppStream |
| libfastjson | 0.99.9 | 5.el9 | aarch64 | AppStream |
| langpacks-core-en | 3.0 | 16.el9 | noarch | AppStream |
| systemd-rpm-macros | 252 | 64.el9 | noarch | anaconda |
| dbus | 1.12.20 | 8.el9 | aarch64 | anaconda |
| systemd-pam | 252 | 64.el9 | aarch64 | anaconda |
| systemd | 252 | 64.el9 | aarch64 | anaconda |
| dbus-common | 1.12.20 | 8.el9 | noarch | anaconda |
| dbus-broker | 28 | 7.el9 | aarch64 | anaconda |
| cronie-anacron | 1.5.7 | 16.el9 | aarch64 | anaconda |
| cronie | 1.5.7 | 16.el9 | aarch64 | anaconda |
| crontabs | 1.11 | 26.20190603git.el9 | noarch | anaconda |
| device-mapper-libs | 1.02.206 | 2.el9 | aarch64 | anaconda |
| device-mapper | 1.02.206 | 2.el9 | aarch64 | anaconda |
| cryptsetup-libs | 2.8.1 | 3.el9 | aarch64 | anaconda |
| systemd-udev | 252 | 64.el9 | aarch64 | anaconda |
| device-mapper-event-libs | 1.02.206 | 2.el9 | aarch64 | anaconda |
| grub2-tools-minimal | 2.06 | 124.el9 | aarch64 | anaconda |
| parted | 3.5 | 3.el9 | aarch64 | anaconda |
| libblockdev-utils | 2.28 | 16.el9 | aarch64 | AppStream |
| iputils | 20210202 | 15.el9 | aarch64 | anaconda |
| NetworkManager | 1.54.3 | 2.el9 | aarch64 | anaconda |
| polkit | 0.117 | 14.el9 | aarch64 | anaconda |
| polkit-pkla-compat | 0.1 | 21.el9 | aarch64 | anaconda |
| libblockdev | 2.28 | 16.el9 | aarch64 | AppStream |
| libblockdev-fs | 2.28 | 16.el9 | aarch64 | AppStream |
| libblockdev-loop | 2.28 | 16.el9 | aarch64 | AppStream |
| libblockdev-part | 2.28 | 16.el9 | aarch64 | AppStream |
| libblockdev-swap | 2.28 | 16.el9 | aarch64 | AppStream |
| os-prober | 1.77 | 12.el9 | aarch64 | anaconda |
| device-mapper-event | 1.02.206 | 2.el9 | aarch64 | anaconda |
| lvm2-libs | 2.03.32 | 2.el9 | aarch64 | anaconda |
| libfido2 | 1.13.0 | 2.el9 | aarch64 | anaconda |
| flashrom | 1.2 | 10.el9 | aarch64 | AppStream |
| kpartx | 0.8.7 | 44.el9 | aarch64 | anaconda |
| xfsprogs | 6.4.0 | 7.el9 | aarch64 | anaconda |
| authselect-libs | 1.2.6 | 3.el9 | aarch64 | anaconda |
| elfutils-default-yama-scope | 0.194 | 1.el9 | noarch | anaconda |
| elfutils-libs | 0.194 | 1.el9 | aarch64 | anaconda |
| elfutils-debuginfod-client | 0.194 | 1.el9 | aarch64 | anaconda |
| binutils-gold | 2.35.2 | 69.el9 | aarch64 | anaconda |
| binutils | 2.35.2 | 69.el9 | aarch64 | anaconda |
| rpm-build-libs | 4.16.1.3 | 40.el9 | aarch64 | anaconda |
| python3-rpm | 4.16.1.3 | 40.el9 | aarch64 | anaconda |
| python3-dnf | 4.14.0 | 33.el9 | noarch | anaconda |
| dnf | 4.14.0 | 33.el9 | noarch | anaconda |
| python3-dnf-plugins-core | 4.3.0 | 26.el9 | noarch | anaconda |
| initscripts-service | 10.11.8 | 4.el9 | noarch | anaconda |
| libkcapi | 1.4.0 | 2.el9 | aarch64 | anaconda |
| libkcapi-hmaccalc | 1.4.0 | 2.el9 | aarch64 | anaconda |
| dracut | 057 | 110.git20260130.el9 | aarch64 | anaconda |
| kernel-modules-core | 5.14.0 | 686.el9 | aarch64 | anaconda |
| kernel-core | 5.14.0 | 686.el9 | aarch64 | anaconda |
| grub2-tools | 2.06 | 124.el9 | aarch64 | anaconda |
| grubby | 8.40 | 69.el9 | aarch64 | anaconda |
| crypto-policies-scripts | 20251126 | 1.gite9c4db2.el9 | noarch | anaconda |
| nss-sysinit | 3.112.0 | 4.el9 | aarch64 | AppStream |
| nss | 3.112.0 | 4.el9 | aarch64 | AppStream |
| volume_key-libs | 0.3.12 | 17.el9 | aarch64 | AppStream |
| libblockdev-crypto | 2.28 | 16.el9 | aarch64 | AppStream |
| kernel-modules | 5.14.0 | 686.el9 | aarch64 | anaconda |
| dracut-network | 057 | 110.git20260130.el9 | aarch64 | anaconda |
| dracut-squash | 057 | 110.git20260130.el9 | aarch64 | anaconda |
| logrotate | 3.18.0 | 12.el9 | aarch64 | anaconda |
| rsyslog-logrotate | 8.2510.0 | 2.el9 | aarch64 | AppStream |
| rsyslog | 8.2510.0 | 2.el9 | aarch64 | AppStream |
| mdadm | 4.4 | 3.el9 | aarch64 | anaconda |
| libblockdev-mdraid | 2.28 | 16.el9 | aarch64 | AppStream |
| udisks2 | 2.9.4 | 12.el9 | aarch64 | AppStream |
| fwupd-plugin-flashrom | 1.9.31 | 1.el9 | aarch64 | AppStream |
| fwupd | 1.9.31 | 1.el9 | aarch64 | anaconda |
| sssd-common | 2.9.8 | 1.el9 | aarch64 | anaconda |
| sssd-kcm | 2.9.8 | 1.el9 | aarch64 | anaconda |
| shim-aa64 | 15.8 | 2.el9 | aarch64 | anaconda |
| kexec-tools | 2.0.29 | 17.el9 | aarch64 | anaconda |
| kernel | 5.14.0 | 686.el9 | aarch64 | anaconda |
| grub2-efi-aa64 | 2.06 | 124.el9 | aarch64 | anaconda |
| dracut-config-rescue | 057 | 110.git20260130.el9 | aarch64 | anaconda |
| audit | 3.1.5 | 8.el9 | aarch64 | anaconda |
| dnf-plugins-core | 4.3.0 | 26.el9 | noarch | anaconda |
| yum | 4.14.0 | 33.el9 | noarch | anaconda |
| authselect | 1.2.6 | 3.el9 | aarch64 | anaconda |
| openssh-clients | 9.9p1 | 3.el9 | aarch64 | anaconda |
| lvm2 | 2.03.32 | 2.el9 | aarch64 | anaconda |
| NetworkManager-team | 1.54.3 | 2.el9 | aarch64 | anaconda |
| NetworkManager-tui | 1.54.3 | 2.el9 | aarch64 | anaconda |
| chrony | 4.8 | 1.el9 | aarch64 | anaconda |
| firewalld | 1.3.4 | 18.el9 | noarch | anaconda |
| openssh-server | 9.9p1 | 3.el9 | aarch64 | anaconda |
| langpacks-en | 3.0 | 16.el9 | noarch | AppStream |
| sg3_utils | 1.47 | 10.el9 | aarch64 | anaconda |
| iproute-tc | 6.17.0 | 2.el9 | aarch64 | anaconda |
| passwd | 0.80 | 12.el9 | aarch64 | anaconda |
| initscripts-rename-device | 10.11.8 | 4.el9 | aarch64 | anaconda |
| irqbalance | 1.9.4 | 5.el9 | aarch64 | anaconda |
| rpm-plugin-selinux | 4.16.1.3 | 40.el9 | aarch64 | anaconda |
| rpm-plugin-audit | 4.16.1.3 | 40.el9 | aarch64 | anaconda |
| sudo | 1.9.17p2 | 2.el9 | aarch64 | anaconda |
| man-db | 2.9.3 | 9.el9 | aarch64 | anaconda |
| kernel-tools | 5.14.0 | 686.el9 | aarch64 | anaconda |
| python3-libselinux | 3.6 | 3.el9 | aarch64 | AppStream |
| prefixdevname | 0.1.0 | 8.el9 | aarch64 | anaconda |
| efibootmgr | 16 | 12.el9 | aarch64 | anaconda |
| vim-minimal | 8.2.2637 | 25.el9 | aarch64 | anaconda |
| lshw | B.02.20 | 4.el9 | aarch64 | anaconda |
| libsysfs | 2.1.1 | 11.el9 | aarch64 | anaconda |
| lsscsi | 0.32 | 6.el9 | aarch64 | anaconda |
| ncurses | 6.2 | 12.20210508.el9 | aarch64 | anaconda |
| rootfiles | 8.1 | 35.el9 | noarch | anaconda |
| git-core | 2.52.0 | 1.el9 | aarch64 | appstream |
| git-core-doc | 2.52.0 | 1.el9 | noarch | appstream |
| perl-Digest | 1.19 | 4.el9 | noarch | appstream |
| perl-Digest-MD5 | 2.58 | 4.el9 | aarch64 | appstream |
| perl-B | 1.80 | 483.el9 | aarch64 | appstream |
| perl-FileHandle | 2.03 | 483.el9 | noarch | appstream |
| perl-Data-Dumper | 2.174 | 462.el9 | aarch64 | appstream |
| perl-libnet | 3.13 | 4.el9 | noarch | appstream |
| perl-base | 2.27 | 483.el9 | noarch | appstream |
| perl-URI | 5.09 | 3.el9 | noarch | appstream |
| perl-AutoLoader | 5.74 | 483.el9 | noarch | appstream |
| perl-Mozilla-CA | 20200520 | 6.el9 | noarch | appstream |
| perl-if | 0.60.800 | 483.el9 | noarch | appstream |
| perl-IO-Socket-IP | 0.41 | 5.el9 | noarch | appstream |
| perl-Time-Local | 1.300 | 7.el9 | noarch | appstream |
| perl-File-Path | 2.18 | 4.el9 | noarch | appstream |
| perl-Pod-Escapes | 1.07 | 460.el9 | noarch | appstream |
| perl-Text-Tabs+Wrap | 2013.0523 | 460.el9 | noarch | appstream |
| perl-IO-Socket-SSL | 2.073 | 2.el9 | noarch | appstream |
| perl-Net-SSLeay | 1.94 | 3.el9 | aarch64 | appstream |
| perl-Class-Struct | 0.66 | 483.el9 | noarch | appstream |
| perl-POSIX | 1.94 | 483.el9 | aarch64 | appstream |
| perl-Term-ANSIColor | 5.01 | 461.el9 | noarch | appstream |
| perl-IPC-Open3 | 1.21 | 483.el9 | noarch | appstream |
| perl-subs | 1.03 | 483.el9 | noarch | appstream |
| perl-File-Temp | 0.231.100 | 4.el9 | noarch | appstream |
| perl-Term-Cap | 1.17 | 460.el9 | noarch | appstream |
| perl-Pod-Simple | 3.42 | 4.el9 | noarch | appstream |
| perl-HTTP-Tiny | 0.076 | 462.el9 | noarch | appstream |
| perl-Socket | 2.031 | 4.el9 | aarch64 | appstream |
| perl-SelectSaver | 1.02 | 483.el9 | noarch | appstream |
| perl-Symbol | 1.08 | 483.el9 | noarch | appstream |
| perl-File-stat | 1.09 | 483.el9 | noarch | appstream |
| perl-podlators | 4.14 | 460.el9 | noarch | appstream |
| perl-Pod-Perldoc | 3.28.01 | 461.el9 | noarch | appstream |
| perl-Fcntl | 1.13 | 483.el9 | aarch64 | appstream |
| perl-Text-ParseWords | 3.30 | 460.el9 | noarch | appstream |
| perl-mro | 1.23 | 483.el9 | aarch64 | appstream |
| perl-IO | 1.43 | 483.el9 | aarch64 | appstream |
| perl-overloading | 0.02 | 483.el9 | noarch | appstream |
| perl-Pod-Usage | 2.01 | 4.el9 | noarch | appstream |
| perl-Errno | 1.30 | 483.el9 | aarch64 | appstream |
| perl-File-Basename | 2.85 | 483.el9 | noarch | appstream |
| perl-Getopt-Std | 1.12 | 483.el9 | noarch | appstream |
| perl-MIME-Base64 | 3.16 | 4.el9 | aarch64 | appstream |
| perl-Scalar-List-Utils | 1.56 | 462.el9 | aarch64 | appstream |
| perl-constant | 1.33 | 461.el9 | noarch | appstream |
| perl-Storable | 3.21 | 460.el9 | aarch64 | appstream |
| perl-overload | 1.31 | 483.el9 | noarch | appstream |
| perl-parent | 0.238 | 460.el9 | noarch | appstream |
| perl-vars | 1.05 | 483.el9 | noarch | appstream |
| perl-Getopt-Long | 2.52 | 4.el9 | noarch | appstream |
| perl-Carp | 1.50 | 460.el9 | noarch | appstream |
| perl-Exporter | 5.74 | 461.el9 | noarch | appstream |
| perl-NDBM_File | 1.15 | 483.el9 | aarch64 | appstream |
| perl-PathTools | 3.78 | 461.el9 | aarch64 | appstream |
| perl-Encode | 3.08 | 462.el9 | aarch64 | appstream |
| perl-libs | 5.32.1 | 483.el9 | aarch64 | appstream |
| perl-interpreter | 5.32.1 | 483.el9 | aarch64 | appstream |
| perl-DynaLoader | 1.47 | 483.el9 | aarch64 | appstream |
| perl-TermReadKey | 2.38 | 11.el9 | aarch64 | appstream |
| perl-Error | 0.17029 | 7.el9 | noarch | appstream |
| perl-lib | 0.65 | 483.el9 | aarch64 | appstream |
| perl-Git | 2.52.0 | 1.el9 | noarch | appstream |
| git | 2.52.0 | 1.el9 | aarch64 | appstream |
| container-selinux | 2.245.0 | 1.el9 | noarch | appstream |
| fuse3-libs | 3.10.2 | 9.el9 | aarch64 | appstream |
| protobuf-c | 1.3.3 | 13.el9 | aarch64 | baseos |
| passt-selinux | 0^20251210.gd04c480 | 3.el9 | noarch | appstream |
| passt | 0^20251210.gd04c480 | 3.el9 | aarch64 | appstream |
| yajl | 2.1.0 | 25.el9 | aarch64 | appstream |
| libslirp | 4.4.0 | 8.el9 | aarch64 | appstream |
| slirp4netns | 1.3.3 | 1.el9 | aarch64 | appstream |
| libnet | 1.2 | 7.el9 | aarch64 | appstream |
| conmon | 2.2.1 | 1.el9 | aarch64 | appstream |
| aardvark-dns | 1.17.0 | 1.el9 | aarch64 | appstream |
| netavark | 1.17.2 | 1.el9 | aarch64 | appstream |
| tar | 1.34 | 11.el9 | aarch64 | baseos |
| criu | 3.19 | 5.el9 | aarch64 | appstream |
| criu-libs | 3.19 | 5.el9 | aarch64 | appstream |
| crun | 1.27 | 2.el9 | aarch64 | appstream |
| shadow-utils-subid | 4.9 | 16.el9 | aarch64 | baseos |
| fuse-common | 3.10.2 | 9.el9 | aarch64 | baseos |
| fuse3 | 3.10.2 | 9.el9 | aarch64 | appstream |
| fuse-overlayfs | 1.16 | 1.el9 | aarch64 | appstream |
| containers-common | 5.8 | 1.el9 | aarch64 | appstream |
| podman | 5.8.2 | 1.el9 | aarch64 | appstream |
| inspectah | 0.7.0 | 1.el9 | aarch64 | copr:copr.fedorainfracloud.org:mrussell:inspectah |
| libmpc | 1.2.1 | 4.el9 | aarch64 | appstream |
| cpp | 11.5.0 | 14.el9 | aarch64 | appstream |
| llvm-filesystem | 22.1.3 | 1.el9 | aarch64 | appstream |
| llvm-libs | 22.1.3 | 1.el9 | aarch64 | appstream |
| libubsan | 11.5.0 | 14.el9 | aarch64 | appstream |
| libasan | 11.5.0 | 14.el9 | aarch64 | appstream |
| kernel-headers | 5.14.0 | 704.el9 | aarch64 | appstream |
| pkgconf-m4 | 1.7.3 | 10.el9 | noarch | baseos |
| make | 4.3 | 8.el9 | aarch64 | baseos |
| libpkgconf | 1.7.3 | 10.el9 | aarch64 | baseos |
| pkgconf | 1.7.3 | 10.el9 | aarch64 | baseos |
| pkgconf-pkg-config | 1.7.3 | 10.el9 | aarch64 | baseos |
| glibc-devel | 2.34 | 256.el9 | aarch64 | appstream |
| libxcrypt-devel | 4.4.18 | 3.el9 | aarch64 | appstream |
| gcc | 11.5.0 | 14.el9 | aarch64 | appstream |
| rust | 1.95.0 | 1.el9 | aarch64 | appstream |
| rust-std-static | 1.95.0 | 1.el9 | aarch64 | appstream |
| cargo | 1.95.0 | 1.el9 | aarch64 | appstream |

## Configuration Files

## Service State Changes

| Unit | Current | Default | Action |
|------|---------|---------|--------|
| dbus-org.fedoraproject.FirewallD1.service | alias | disabled | disable |
| dbus-org.freedesktop.hostname1.service | alias | disabled | disable |
| dbus-org.freedesktop.locale1.service | alias | disabled | disable |
| dbus-org.freedesktop.login1.service | alias | disabled | disable |
| dbus-org.freedesktop.nm-dispatcher.service | alias | disabled | disable |
| dbus-org.freedesktop.timedate1.service | alias | disabled | disable |
| dbus.service | alias | disabled | disable |
| NetworkManager-wait-online.service | enabled | disabled | enable |
| sssd-autofs.service | indirect | disabled | disable |
| sssd-kcm.service | indirect | disabled | disable |
| sssd-nss.service | indirect | disabled | disable |
| sssd-pac.service | indirect | disabled | disable |
| sssd-pam.service | indirect | disabled | disable |
| sssd-ssh.service | indirect | disabled | disable |
| sssd-sudo.service | indirect | disabled | disable |
| systemd-remount-fs.service | enabled-runtime | disabled | disable |
| systemd-sysupdate-reboot.service | indirect | disabled | disable |
| systemd-sysupdate.service | indirect | disabled | disable |

## Storage

### Fstab Entries (5)

| Device | Mount Point | Type | Options |
|--------|-------------|------|---------|
| /dev/mapper/cs-root | / | xfs | defaults |
| UUID=3db302f0-345d-4cd3-bce4-e56e66d05ca7 | /boot | xfs | defaults |
| UUID=5440-F2DF | /boot/efi | vfat | umask=0077,shortname=winnt |
| /dev/mapper/cs-home | /home | xfs | defaults |
| /dev/mapper/cs-swap | none | swap | defaults |

### LVM Volumes (3)

| LV Name | VG Name | Size |
|---------|---------|------|
| home | cs | 19.80g |
| root | cs | 40.57g |
| swap | cs | <2.04g |

## Kernel & Boot

### Kernel Command Line

`BOOT_IMAGE=(hd0,gpt2)/vmlinuz-5.14.0-686.el9.aarch64 root=/dev/mapper/cs-root ro crashkernel=1G-4G:256M,4G-64G:320M,64G-:576M rd.lvm.lv=cs/root rd.lvm.lv=cs/swap`

### Modprobe Configs (1)

- `/etc/modprobe.d/firewalld-sysctls.conf`

## Scheduled Tasks

- **Cron jobs:** 3
- **Systemd timers:** 15
- **At jobs:** 0

## Security & Access Control

- **Mode:** Enforcing

## Non-RPM Software

### Items (1)

- pip dist-info: 1

## Redactions

23 item(s) redacted. See `secrets-review.md` for details.

## Warnings

- degraded: config inspector degraded: file too large (541716 bytes): /etc/ssh/moduli; file too large (676522 bytes): /etc/ssl/certs/ca-bundle.trust.crt; file too large (692252 bytes): /etc/services
