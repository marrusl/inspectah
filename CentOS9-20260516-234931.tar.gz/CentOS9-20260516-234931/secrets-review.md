# Secrets Review

> Detected secrets: 22 redacted (22 inline), 1 flagged for review

The following items were redacted or excluded. Handle them according to
the action specified for each item.

## Inline Redactions

Secret values in these files/entries were replaced with `[REDACTED-*]` tokens.

| Path | Line | Pattern | Detection |
|------|------|---------|-----------|
| /etc/authselect/user-nsswitch.conf | 50 | password | pattern |
| /etc/authselect/user-nsswitch.conf | 54 | password | pattern |
| /etc/libuser.conf | 32 | password | pattern |
| /etc/libuser.conf | 38 | password | pattern |
| /etc/libuser.conf | 52 | password | pattern |
| /etc/nsswitch.conf | 50 | password | pattern |
| /etc/nsswitch.conf | 54 | password | pattern |
| /etc/nsswitch.conf.bak | 50 | password | pattern |
| /etc/nsswitch.conf.bak | 54 | password | pattern |
| /etc/security/namespace.init | 31 | password | pattern |
| /etc/selinux/semanage.conf | 52 | password | pattern |
| /etc/shadow | 1 | shadow_hash | pattern |
| /etc/shadow | 21 | shadow_hash | pattern |
| /etc/ssl/openssl.cnf | 107 | password | pattern |
| /etc/ssl/openssl.cnf | 165 | password | pattern |
| /etc/ssl/openssl.cnf | 166 | password | pattern |
| /etc/ssl/openssl.cnf | 210 | password | pattern |
| /etc/ssl/openssl.cnf | 364 | password | pattern |
| /etc/ssl/openssl.cnf | 378 | password | pattern |
| /etc/ssl/openssl.cnf | 385 | password | pattern |
| /etc/sudoers | 111 | password | pattern |
| usr/lib/systemd/system/systemd-tmpfiles-clean.timer:systemd-tmpfiles-clean.service | 25 | password | pattern |

## Flagged for Review

| Path | Line | Confidence | Why Flagged |
|------|------|------------|-------------|
| /etc/shadow | -- | -- | inspector_hint |
