#version=RHEL9

# Kickstart suggestion -- review and adapt for your environment
# These settings belong at deploy time, not baked into the image.

# --- DHCP connections ---
network --bootproto=dhcp --device=enp0s5 --activate

# --- Static connections ---
# FIXME: fill in IP, netmask, gateway for each static connection
# network --bootproto=static --device=mgmt --ip=FIXME --netmask=FIXME --gateway=FIXME

network --hostname=web-03

# --- /etc/hosts additions ---
%post
echo "10.10.10.10 app.internal app" >> /etc/hosts
echo "10.10.10.11 db.internal db" >> /etc/hosts
%end

# --- Static route files detected ---
# These files were present on the source host. Review each and translate
# to NM connection properties (+ipv4.routes) or kickstart route directives.
# FIXME: review etc/sysconfig/network-scripts/route-eth0 and add equivalent route to NM connection or kickstart
# FIXME: review etc/iproute2/README and add equivalent route to NM connection or kickstart

# --- Examples ---
# network --bootproto=dhcp --device=eth0
# network --hostname=myhost.example.com
# network --bootproto=static --ip=192.168.1.10 --netmask=255.255.255.0 --gateway=192.168.1.1

# --- Remote filesystem mounts detected ---
# NFS: nfs.internal:/exports/myapp -> /mnt/myapp-nfs
#   FIXME: provide NFS credentials at deploy time
# CIFS: //files.internal/myshare -> /mnt/myapp-cifs
#   FIXME: provide CIFS credentials (username/password) at deploy time
