# Secrets Review

> Detected secrets: 19 redacted (19 inline), 5 flagged for review

The following items were redacted or excluded. Handle them according to
the action specified for each item.

## Inline Redactions

Secret values in these files/entries were replaced with `[REDACTED-*]` tokens.

| Path | Line | Pattern | Detection |
|------|------|---------|-----------|
| /etc/containers/systemd/redis.container | 10 | password | pattern |
| /etc/containers/systemd/webapp.container | 13 | postgrespassword | pattern |
| /etc/myapp/app.conf | 9 | password | pattern |
| /etc/myapp/app.conf | 8 | awskey | pattern |
| /etc/myapp/cifs.creds | 2 | password | pattern |
| /etc/myapp/database.yml | 10 | password | pattern |
| /etc/myapp/database.yml | 11 | postgrespassword | pattern |
| /etc/myapp/server.key | 1 | privatekey | pattern |
| /etc/nsswitch.conf.bak | 50 | password | pattern |
| /etc/nsswitch.conf.bak | 54 | password | pattern |
| /etc/profile.d/custom-env.sh | 7 | redispassword | pattern |
| /etc/sudoers.d/appusers | 3 | password | pattern |
| /etc/sudoers.d/appusers | 4 | password | pattern |
| /etc/fstab | -- | credential_mount_option | heuristic (high) |
| usr/lib/systemd/system/systemd-tmpfiles-clean.timer:systemd-tmpfiles-clean.service | 25 | password | pattern |
| opt/myapp/.env | 2 | password | pattern |
| opt/myapp/.env | 3 | mongodbpassword | pattern |
| /etc/sudoers | 2 | password | pattern |
| /etc/sudoers | 2 | password | pattern |

## Flagged for Review

| Path | Line | Confidence | Why Flagged |
|------|------|------------|-------------|
| /etc/fstab | -- | medium | credential_file_ref |
| /etc/fstab | -- | medium | inspector_hint |
| opt/myapp/docker-compose.yml | -- | -- | inspector_hint |
| /etc/shadow | -- | -- | inspector_hint |
| opt/myapp/.env | -- | high | inspector_hint |
