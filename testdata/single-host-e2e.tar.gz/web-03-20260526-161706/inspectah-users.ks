group --name=mark --gid=1000
group --name=appgroup --gid=1001
group --name=dbuser --gid=1002
group --name=developers --gid=1050
user --name=mark --uid=1000 --gid=1000 --shell=/bin/bash --homedir=/home/mark --groups=wheel
user --name=appuser --uid=1001 --gid=1001 --shell=/bin/bash --homedir=/home/appuser --groups=developers
user --name=dbuser --uid=1002 --gid=1002 --shell=/sbin/nologin --homedir=/home/dbuser --groups=developers