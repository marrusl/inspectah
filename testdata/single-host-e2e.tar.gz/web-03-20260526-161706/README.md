# inspectah output

Generated from **CentOS Stream 9**.

Hostname: `web-03`

## Findings summary

| Category | Count |
|---|---|
| Packages added (beyond base image) | 605 |
| Services (24 enabled, 24 disabled) | 48 |
| Non-RPM software items | 5 |
| Container workloads | 4 quadlet, 1 compose |
| Secrets redacted | 24 |
| Warnings | 1 |

## Build and deploy

```bash
podman build -t my-bootc-image -f Containerfile .
```

```bash
# Custom kernel args detected -- verify they are baked into the image
# or pass them via the bootloader configuration at deploy time.
# Switch an existing system to the new image:
bootc switch my-bootc-image:latest

# Or install to a new disk:
bootc install to-disk --target-no-signature-verification /dev/sdX
```

Review `kickstart-suggestion.ks` for deployment-time settings (hostname, DHCP, DNS).

## Artifacts

| File | Description |
|---|---|
| `Containerfile` | Image definition |
| `config/` | Files to COPY into the image |
| `audit-report.md` | Full findings (markdown) |
| `report.html` | Interactive report (open in browser) |
| `secrets-review.md` | Redacted items requiring manual handling |
| `kickstart-suggestion.ks` | Suggested deploy-time settings |
| `inspection-snapshot.json` | Raw data for re-rendering (`--from-snapshot`) |

## Warnings

- **services:** unit systemd-remount-fs.service has state 'enabled-runtime' - transient state is not migrated

See [`audit-report.md`](audit-report.md) or [`report.html`](report.html) for full details.

## Baseline comparison

| | |
|---|---|
| Target image | quay.io/centos-bootc/centos-bootc:stream9 |
| Resolution | os-release (auto-detected) |
| Image digest | sha256:4817ae279b49276fc32da9d10c9c8fc8d4e11c5e991b2bfc68899fe50c0cec85 |
| Baseline extracted | 2026-05-26T21:15:34Z |
| Baseline packages | 447 |
| Version changes | 95 shared packages with version changes (80 target-newer, 15 host-newer), 222 not in base image |
