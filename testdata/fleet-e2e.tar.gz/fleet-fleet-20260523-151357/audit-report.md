# Audit Report

## Fleet Aggregate Summary

- **Label:** fleet
- **Host count:** 3
- **Fleet baseline:** Unanimous (all hosts match)

### Hosts

- fleet-host-01.example.com
- fleet-host-02.example.com
- fleet-host-03.example.com

### Section Coverage

| Section | Hosts |
|---------|-------|
| config | 3 |
| rpm | 3 |
| services | 3 |

**Variant conflicts:** 2 path(s) with multiple content versions across the fleet

**Source system:** Red Hat Enterprise Linux 9.4

## Packages

### Added Packages (3)

| Name | Version | Release | Arch | Repo |
|------|---------|---------|------|------|
| httpd | 2.4.57 | 11.el9 | x86_64 | rhel-9-for-x86_64-appstream-rpms |
| mod_ssl | 2.4.57 | 11.el9 | x86_64 | rhel-9-for-x86_64-appstream-rpms |
| strace | 6.7 | 1.el9 | x86_64 | rhel-9-for-x86_64-baseos-rpms |

## Configuration Files

### Modified RPM-Owned Files (3)

#### `/etc/httpd/conf/httpd.conf`

#### `/etc/httpd/conf/httpd.conf`

#### `/etc/httpd/conf/httpd.conf`

### Unowned Config Files (2)

- `/etc/sysctl.d/99-custom.conf` (sysctl)
- `/etc/sysctl.d/99-custom.conf` (sysctl)

## Service State Changes

| Unit | Current | Default | Action |
|------|---------|---------|--------|
| httpd.service | enabled | disable | enable |
