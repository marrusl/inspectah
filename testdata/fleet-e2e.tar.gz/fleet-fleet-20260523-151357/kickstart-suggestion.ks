#version=RHEL9

# Kickstart suggestion -- review and adapt for your environment
# These settings belong at deploy time, not baked into the image.

# --- Examples ---
# network --bootproto=dhcp --device=eth0
# network --hostname=myhost.example.com
# network --bootproto=static --ip=192.168.1.10 --netmask=255.255.255.0 --gateway=192.168.1.1
