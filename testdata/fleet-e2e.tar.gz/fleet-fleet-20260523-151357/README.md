# inspectah output

Generated from **Red Hat Enterprise Linux 9.4**.

Hostname: `fleet-host-01.example.com`

## Findings summary

| Category | Count |
|---|---|
| Packages added (beyond base image) | 3 |
| Services (1 enabled, 0 disabled) | 1 |
| Warnings | 0 |

## Build and deploy

```bash
podman build -t my-bootc-image -f Containerfile .
```

```bash
# Switch an existing system to the new image:
bootc switch my-bootc-image:latest

# Or install to a new disk:
bootc install to-disk /dev/sdX
```

Review `kickstart-suggestion.ks` for deployment-time settings (hostname, DHCP, DNS).

## Artifacts

| File | Description |
|---|---|
| `Containerfile` | Image definition |
| `config/` | Files to COPY into the image |
| `audit-report.md` | Full findings (markdown) |
| `report.html` | Interactive report (open in browser) |
| `secrets-review.md` | Redacted items requiring manual handling |
| `kickstart-suggestion.ks` | Suggested deploy-time settings |
| `inspection-snapshot.json` | Raw data for re-rendering (`--from-snapshot`) |

See [`audit-report.md`](audit-report.md) or [`report.html`](report.html) for full details.
