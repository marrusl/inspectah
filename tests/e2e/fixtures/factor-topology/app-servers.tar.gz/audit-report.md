# Audit Report

**OS:** Red Hat Enterprise Linux 9.4 (Plow)

## Executive Summary

**17** items handled automatically &nbsp;|&nbsp; **1** items with FIXME (need review) &nbsp;|&nbsp; **0** items need manual intervention

- Packages added (beyond base image): 15
- Packages in target image only: 0
- Config files captured: 1
- Containers/quadlet found: 0
- Secrets redacted: 0

## RPM / Packages

### Added
- bash-completion 1.0-1.el9.x86_64
- bind-utils 1.0-1.el9.x86_64
- curl 1.0-1.el9.x86_64
- jq 1.0-1.el9.x86_64
- lsof 1.0-1.el9.x86_64
- net-tools 1.0-1.el9.x86_64
- rsync 1.0-1.el9.x86_64
- strace 1.0-1.el9.x86_64
- tcpdump 1.0-1.el9.x86_64
- unzip 1.0-1.el9.x86_64
- java-17-openjdk 1.0-1.el9.x86_64
- tomcat 1.0-1.el9.x86_64
- maven 1.0-1.el9.x86_64
- redis 1.0-1.el9.x86_64
- haproxy 1.0-1.el9.x86_64

## Services

| Unit | Current | Default | Action |
|------|---------|---------|--------|
| app-servers.service | enabled | disabled | enable |

## Configuration Files

- RPM-owned modified: 0
- Unowned: 1
- `/etc/app-servers/app.conf` (unowned)

## Data Migration Plan (/var)

Content under `/var` is seeded at initial bootstrap and **not updated** by subsequent bootc deployments.
`tmpfiles.d` snippets ensure expected directories exist on every boot.
Review application data under `/var/lib`, `/var/log`, `/var/data` for separate migration strategies.

*No significant application data directories found under `/var`.*

## Environment-specific considerations

**Note:** bootc uses a 3-way merge strategy for `/etc` during image updates. Local changes to `/etc` persist across updates, but the merge behavior has nuances — see the [bootc filesystem documentation](https://containers.github.io/bootc/filesystem.html) for details.
