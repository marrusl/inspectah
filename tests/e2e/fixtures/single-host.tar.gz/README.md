# yoinkc output

Generated from **CentOS Stream 9**.

**Host:** `dev-workstation`
**Inspected:** 2026-03-30T12:00:00Z

## Findings summary

| Category | Count |
|---|---|
| Packages added (beyond base image) | 3 |
| Configs modified (RPM-owned) | 0 |
| Configs unowned | 2 |
| Services changed | 0 (0 enabled, 0 disabled) |
| Warnings | 0 |
| FIXME items | 1 |

## Build

```bash
podman build -t my-bootc-image:latest .
```

## Deploy

```bash
# Switch an existing system to the new image:
bootc switch my-bootc-image:latest

# Or install to a new disk:
bootc install to-disk --target-no-signature-verification /dev/sdX
```

Review `kickstart-suggestion.ks` for deployment-time settings (hostname, DHCP, DNS).

## Artifacts

| File | Description |
|---|---|
| `Containerfile` | Image definition |
| `config/` | Files to COPY into the image |
| `audit-report.md` | Full findings (markdown) |
| `report.html` | Interactive report (open in browser) |
| `secrets-review.md` | Redacted items requiring manual handling |
| `kickstart-suggestion.ks` | Suggested deploy-time settings |
| `inspection-snapshot.json` | Raw data for re-rendering (`--from-snapshot`) |

## FIXME items (resolve before production)

1. FIXME: review kickstart-suggestion.ks for deployment-time config

See [`audit-report.md`](audit-report.md) or [`report.html`](report.html) for full details.
