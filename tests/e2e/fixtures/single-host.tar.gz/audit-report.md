# Audit Report

**OS:** CentOS Stream 9

## Executive Summary

**6** items handled automatically &nbsp;|&nbsp; **1** items with FIXME (need review) &nbsp;|&nbsp; **0** items need manual intervention

- Packages added (beyond base image): 3
- Packages in target image only: 0
- Config files captured: 2
- Containers/quadlet found: 0
- Secrets redacted: 0

## RPM / Packages

### Added
- vim-enhanced 9.0.2081-1.el9.x86_64
- tmux 3.3a-3.el9.x86_64
- git 2.43.0-1.el9.x86_64

## Services

| Unit | Current | Default | Action |
|------|---------|---------|--------|
| chronyd.service | enabled | disabled | enable |

## Configuration Files

- RPM-owned modified: 0
- Unowned: 2
- `/etc/vimrc.local` (unowned)
- `/etc/tmux.conf` (unowned)

## Data Migration Plan (/var)

Content under `/var` is seeded at initial bootstrap and **not updated** by subsequent bootc deployments.
`tmpfiles.d` snippets ensure expected directories exist on every boot.
Review application data under `/var/lib`, `/var/log`, `/var/data` for separate migration strategies.

*No significant application data directories found under `/var`.*

## Environment-specific considerations

**Note:** bootc uses a 3-way merge strategy for `/etc` during image updates. Local changes to `/etc` persist across updates, but the merge behavior has nuances — see the [bootc filesystem documentation](https://containers.github.io/bootc/filesystem.html) for details.
