# Secrets Review

The following items were redacted or excluded. Handle them manually (e.g. Kubernetes secret, systemd credential, env at deploy).

| Path | Pattern | Line | Remediation |
|------|---------|------|-------------|
| /etc/app-secrets.conf | API_KEY=sk-.* |  |  |
