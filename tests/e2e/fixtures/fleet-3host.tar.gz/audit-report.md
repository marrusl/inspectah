# Audit Report

**OS:** Red Hat Enterprise Linux 9.4 (Plow)

## Executive Summary

**11** items handled automatically &nbsp;|&nbsp; **1** items with FIXME (need review) &nbsp;|&nbsp; **1** items need manual intervention

- Packages added (beyond base image): 8
- Packages in target image only: 0
- Config files captured: 1
- Containers/quadlet found: 0
- Secrets redacted: 1

## RPM / Packages

### Added
- httpd 2.4.57-5.el9.x86_64
- mod_ssl 2.4.57-5.el9.x86_64
- php 8.1.27-1.el9.x86_64
- redis 7.0.12-1.el9.x86_64
- memcached 1.6.22-1.el9.x86_64
- nginx 1.24.0-2.el9.x86_64
- certbot 2.6.0-1.el9.x86_64
- [EXCLUDED] debug-tools 1.0.0-1.el9.x86_64

## Services

| Unit | Current | Default | Action |
|------|---------|---------|--------|
| httpd.service | enabled | disabled | enable |
| redis.service | enabled | disabled | enable |
| firewalld.service | disabled | enabled | disable |
| [EXCLUDED] debug-helper.service | enabled | disabled | enable |

## Configuration Files

- RPM-owned modified: 5
- Unowned: 3
- [EXCLUDED] `/etc/app.conf` (unowned)
- [EXCLUDED] `/etc/app.conf` (unowned)
- [EXCLUDED] `/etc/httpd/conf/httpd.conf` (rpm_owned_modified)
- [EXCLUDED] `/etc/httpd/conf/httpd.conf` (rpm_owned_modified)
- [EXCLUDED] `/etc/httpd/conf/httpd.conf` (rpm_owned_modified)
- `/etc/nginx/nginx.conf` (rpm_owned_modified)
- [EXCLUDED] `/etc/nginx/nginx.conf` (rpm_owned_modified)
- [EXCLUDED] `/etc/motd` (unowned)

## Data Migration Plan (/var)

Content under `/var` is seeded at initial bootstrap and **not updated** by subsequent bootc deployments.
`tmpfiles.d` snippets ensure expected directories exist on every boot.
Review application data under `/var/lib`, `/var/log`, `/var/data` for separate migration strategies.

*No significant application data directories found under `/var`.*

## Environment-specific considerations

**Note:** bootc uses a 3-way merge strategy for `/etc` during image updates. Local changes to `/etc` persist across updates, but the merge behavior has nuances — see the [bootc filesystem documentation](https://containers.github.io/bootc/filesystem.html) for details.

## Redactions (secrets)

- **/etc/app-secrets.conf**: API_KEY=sk-.* — 
